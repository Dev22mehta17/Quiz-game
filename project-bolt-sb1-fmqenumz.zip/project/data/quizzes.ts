import { Quiz } from '@/types/quiz';

export const quizzes: Quiz[] = [
  {
    id: '1',
    title: 'JavaScript Fundamentals',
    description: 'Test your knowledge of JavaScript basics',
    questions: [
      {
        id: '1-1',
        text: 'What is JavaScript?',
        options: [
          {
            id: '1-1-1',
            text: 'A programming language',
            isCorrect: true,
          },
          {
            id: '1-1-2',
            text: 'A markup language',
            isCorrect: false,
          },
          {
            id: '1-1-3',
            text: 'A styling language',
            isCorrect: false,
          },
          {
            id: '1-1-4',
            text: 'A database',
            isCorrect: false,
          },
        ],
      },
      {
        id: '1-2',
        text: 'Which keyword is used to declare variables in JavaScript?',
        options: [
          {
            id: '1-2-1',
            text: 'var',
            isCorrect: false,
          },
          {
            id: '1-2-2',
            text: 'let',
            isCorrect: true,
          },
          {
            id: '1-2-3',
            text: 'const',
            isCorrect: false,
          },
          {
            id: '1-2-4',
            text: 'variable',
            isCorrect: false,
          },
        ],
      },
    ],
  },
  {
    id: '2',
    title: 'React Native Basics',
    description: 'Test your knowledge of React Native',
    questions: [
      {
        id: '2-1',
        text: 'What is React Native?',
        options: [
          {
            id: '2-1-1',
            text: 'A mobile framework',
            isCorrect: true,
          },
          {
            id: '2-1-2',
            text: 'A database',
            isCorrect: false,
          },
          {
            id: '2-1-3',
            text: 'A web browser',
            isCorrect: false,
          },
          {
            id: '2-1-4',
            text: 'An operating system',
            isCorrect: false,
          },
        ],
      },
      {
        id: '2-2',
        text: 'Which component is used to handle user input in React Native?',
        options: [
          {
            id: '2-2-1',
            text: 'Input',
            isCorrect: false,
          },
          {
            id: '2-2-2',
            text: 'TextInput',
            isCorrect: true,
          },
          {
            id: '2-2-3',
            text: 'TextField',
            isCorrect: false,
          },
          {
            id: '2-2-4',
            text: 'InputText',
            isCorrect: false,
          },
        ],
      },
    ],
  },
];