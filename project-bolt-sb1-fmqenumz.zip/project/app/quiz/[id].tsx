import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, BackHandler } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { quizzes } from '@/data/quizzes';
import { Option, QuizResult } from '@/types/quiz';
import { Check, X } from 'lucide-react-native';

export default function QuizScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const quiz = quizzes.find((q) => q.id === id);

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [quizResults, setQuizResults] = useState<QuizResult>({
    quizId: id as string,
    correctAnswers: 0,
    incorrectAnswers: 0,
    questionResults: [],
  });

  useEffect(() => {
    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      () => true
    );

    return () => backHandler.remove();
  }, []);

  if (!quiz) {
    return (
      <View style={styles.container}>
        <Text>Quiz not found</Text>
      </View>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === quiz.questions.length - 1;

  const handleOptionSelect = (optionId: string) => {
    if (!hasAnswered) {
      setSelectedOption(optionId);
    }
  };

  const handleCheckAnswer = () => {
    const selectedOptionData = currentQuestion.options.find(
      (opt) => opt.id === selectedOption
    );
    const isCorrect = selectedOptionData?.isCorrect ?? false;

    setQuizResults((prev) => ({
      ...prev,
      correctAnswers: prev.correctAnswers + (isCorrect ? 1 : 0),
      incorrectAnswers: prev.incorrectAnswers + (isCorrect ? 0 : 1),
      questionResults: [
        ...prev.questionResults,
        {
          questionId: currentQuestion.id,
          correct: isCorrect,
          selectedOptionId: selectedOption!,
        },
      ],
    }));

    setHasAnswered(true);
  };

  const handleNext = () => {
    if (isLastQuestion) {
      router.push({
        pathname: '/quiz/results',
        params: { results: JSON.stringify(quizResults) },
      });
    } else {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedOption(null);
      setHasAnswered(false);
    }
  };

  const getOptionStyle = (option: Option) => {
    if (!hasAnswered) {
      return option.id === selectedOption
        ? styles.optionSelected
        : styles.option;
    }

    if (option.isCorrect) {
      return styles.optionCorrect;
    }

    if (option.id === selectedOption && !option.isCorrect) {
      return styles.optionIncorrect;
    }

    return styles.option;
  };

  return (
    <View style={styles.container}>
      <Text style={styles.questionNumber}>
        Question {currentQuestionIndex + 1} of {quiz.questions.length}
      </Text>
      <Text style={styles.questionText}>{currentQuestion.text}</Text>

      <View style={styles.optionsContainer}>
        {currentQuestion.options.map((option) => (
          <TouchableOpacity
            key={option.id}
            style={getOptionStyle(option)}
            onPress={() => handleOptionSelect(option.id)}
            disabled={hasAnswered}
          >
            <Text style={styles.optionText}>{option.text}</Text>
            {hasAnswered && option.isCorrect && (
              <Check color="green" size={20} />
            )}
            {hasAnswered && !option.isCorrect && option.id === selectedOption && (
              <X color="red" size={20} />
            )}
          </TouchableOpacity>
        ))}
      </View>

      <TouchableOpacity
        style={[
          styles.button,
          (!selectedOption && !hasAnswered) && styles.buttonDisabled,
        ]}
        onPress={hasAnswered ? handleNext : handleCheckAnswer}
        disabled={!selectedOption && !hasAnswered}
      >
        <Text style={styles.buttonText}>
          {hasAnswered ? (isLastQuestion ? 'Finish' : 'Next') : 'Check Answer'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  questionNumber: {
    fontSize: 16,
    color: '#666',
    marginBottom: 8,
  },
  questionText: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 24,
    color: '#333',
  },
  optionsContainer: {
    marginBottom: 24,
  },
  option: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ddd',
  },
  optionSelected: {
    backgroundColor: '#e3f2fd',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#2196f3',
  },
  optionCorrect: {
    backgroundColor: '#e8f5e9',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#4caf50',
  },
  optionIncorrect: {
    backgroundColor: '#ffebee',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#f44336',
  },
  optionText: {
    fontSize: 16,
    color: '#333',
  },
  button: {
    backgroundColor: '#2196f3',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonDisabled: {
    backgroundColor: '#bdbdbd',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});