import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { QuizResult } from '@/types/quiz';
import { quizzes } from '@/data/quizzes';
import { Check, X } from 'lucide-react-native';

export default function QuizResultsScreen() {
  const { results } = useLocalSearchParams();
  const quizResults: QuizResult = JSON.parse(results as string);
  const quiz = quizzes.find((q) => q.id === quizResults.quizId);

  if (!quiz) {
    return (
      <View style={styles.container}>
        <Text>Quiz not found</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Quiz Results</Text>
      
      <View style={styles.scoreCard}>
        <Text style={styles.quizTitle}>{quiz.title}</Text>
        <View style={styles.scoreRow}>
          <View style={styles.scoreItem}>
            <Text style={styles.scoreLabel}>Correct</Text>
            <Text style={styles.scoreValue}>{quizResults.correctAnswers}</Text>
          </View>
          <View style={styles.scoreItem}>
            <Text style={styles.scoreLabel}>Incorrect</Text>
            <Text style={styles.scoreValue}>{quizResults.incorrectAnswers}</Text>
          </View>
          <View style={styles.scoreItem}>
            <Text style={styles.scoreLabel}>Score</Text>
            <Text style={styles.scoreValue}>
              {Math.round((quizResults.correctAnswers / quiz.questions.length) * 100)}%
            </Text>
          </View>
        </View>
      </View>

      <Text style={styles.sectionTitle}>Question Summary</Text>
      {quiz.questions.map((question, index) => {
        const result = quizResults.questionResults.find(
          (r) => r.questionId === question.id
        );
        const selectedOption = question.options.find(
          (o) => o.id === result?.selectedOptionId
        );
        const correctOption = question.options.find((o) => o.isCorrect);

        return (
          <View key={question.id} style={styles.questionCard}>
            <Text style={styles.questionNumber}>Question {index + 1}</Text>
            <Text style={styles.questionText}>{question.text}</Text>
            
            <View style={styles.answerSummary}>
              <View style={styles.answerRow}>
                <Text style={styles.answerLabel}>Your Answer:</Text>
                <Text style={styles.answerText}>
                  {selectedOption?.text}
                  {result?.correct ? (
                    <Check color="green" size={16} />
                  ) : (
                    <X color="red" size={16} />
                  )}
                </Text>
              </View>
              
              {!result?.correct && (
                <View style={styles.answerRow}>
                  <Text style={styles.answerLabel}>Correct Answer:</Text>
                  <Text style={styles.correctAnswerText}>
                    {correctOption?.text}
                  </Text>
                </View>
              )}
            </View>
          </View>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  scoreCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  quizTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  scoreRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  scoreItem: {
    alignItems: 'center',
  },
  scoreLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  scoreValue: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  questionCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  questionNumber: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  questionText: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  answerSummary: {
    backgroundColor: '#f8f9fa',
    padding: 12,
    borderRadius: 8,
  },
  answerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  answerLabel: {
    fontSize: 14,
    color: '#666',
  },
  answerText: {
    fontSize: 14,
    color: '#333',
  },
  correctAnswerText: {
    fontSize: 14,
    color: '#4caf50',
    fontWeight: 'bold',
  },
});